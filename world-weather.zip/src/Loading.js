import React from "react";

const Loading = () => {
  return <h3>Loading...</h3>;
};

export default Loading;
